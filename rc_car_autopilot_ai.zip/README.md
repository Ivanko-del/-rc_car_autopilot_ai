# 🤖 RC Car Autopilot with AI Voice Assistant

## 🇺🇦 Українською

Цей проєкт додає автопілот та голосового асистента з GPT до міні-радіокерованої машинки на Raspberry Pi.

### Можливості:
- Автопілот із датчиком відстані
- Голосовий інтерфейс (українська мова)
- Відповіді GPT через мікрофон і динамік

### Необхідне:
- Raspberry Pi (з інтернетом)
- Динамік, мікрофон
- Датчик відстані (HC-SR04)
- Мотори та драйвер (через GPIO)
- Python 3.9+

### Встановлення:
```bash
pip install -r requirements.txt
python main.py
```

---

## 🇬🇧 English

This project adds autopilot and a GPT voice assistant to an RC car using Raspberry Pi.

### Features:
- Autopilot with distance sensor
- Voice interface (Ukrainian language)
- GPT responses via speaker and microphone

### Requirements:
- Raspberry Pi (with internet)
- Speaker, microphone
- Distance sensor (HC-SR04)
- Motors & driver via GPIO
- Python 3.9+

### Installation:
```bash
pip install -r requirements.txt
python main.py
```
import speech_recognition as sr
import pyttsx3
import openai
import time
from gpiozero import Motor, DistanceSensor
import threading

openai.api_key = "тут_твій_ключ"

recognizer = sr.Recognizer()
tts = pyttsx3.init()

def speak(text):
    tts.say(text)
    tts.runAndWait()

motor_left = Motor(forward=17, backward=18)
motor_right = Motor(forward=22, backward=23)
sensor = DistanceSensor(echo=24, trigger=25)

def autopilot():
    while True:
        distance = sensor.distance * 100
        if distance < 20:
            motor_left.backward()
            motor_right.backward()
            time.sleep(0.5)
            motor_left.forward()
            motor_right.backward()
            time.sleep(0.3)
        else:
            motor_left.forward()
            motor_right.forward()
        time.sleep(0.1)

def ask_gpt(question):
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": question}]
    )
    return response["choices"][0]["message"]["content"]

def voice_interface():
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(source)
        speak("Привіт! Я автопілот. Питай мене щось!")
        while True:
            try:
                print("Слухаю...")
                audio = recognizer.listen(source, timeout=5)
                command = recognizer.recognize_google(audio, language="uk-UA")
                print("Ти сказав:", command)

                if "стоп" in command.lower():
                    speak("Зупиняюсь.")
                    motor_left.stop()
                    motor_right.stop()
                    break

                reply = ask_gpt(command)
                print("GPT:", reply)
                speak(reply)

            except sr.UnknownValueError:
                speak("Я не зрозумів, повтори ще раз.")
            except sr.WaitTimeoutError:
                continue
            except Exception as e:
                print("Помилка:", e)
                speak("Виникла помилка.")

autopilot_thread = threading.Thread(target=autopilot)
voice_thread = threading.Thread(target=voice_interface)

autopilot_thread.start()
voice_thread.start()